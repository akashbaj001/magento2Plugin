import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => <p className="List-noItems">Page not found.</p>;

export default NotFound;
