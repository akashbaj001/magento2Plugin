import React from 'react';
import { render } from 'react-dom';
import Form from './design-form';

const App = () => <Form />;

render(<App />, document.getElementById('content'));
