import React from 'react';
import { render } from 'react-dom';
import Form from './content-form';

const App = () => <Form />;

render(<App />, document.getElementById('content'));
