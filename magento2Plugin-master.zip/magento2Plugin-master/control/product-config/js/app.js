import React from 'react';
import { render } from 'react-dom';
import Form from './product-config-form';

const App = () => <Form />;

render(<App />, document.getElementById('content'));
